#!/bin/sh

sudo rm -rf build
#ifndef CSSERVER_H
#define CSSERVER_H

#include <string>

#include <boost/shared_ptr.hpp>
#include <boost/unordered_map.hpp>

#include <muduo/net/TcpConnection.h>
#include <muduo/net/TcpServer.h>
#include <muduo/net/TcpClient.h>
#include <muduo/base/Timestamp.h>

#include "TableManager.h"
#include "DRowTable.h"
#include "HeartBeatManager.h"
#include "ProtobufCodec.h"
#include "ProtobufLabCodec.h"
#include "ProtobufDispatcher.h"

typedef boost::shared_ptr<muduo::net::TcpClient> TcpClientPtr;
typedef boost::shared_ptr<TableManager> TableManagerPtr;
typedef boost::shared_ptr<DRowTable> DRowTablePtr;

class CSServer
{
public:

    CSServer();
    void start();
    void onCliConnection(muduo::net::TcpConnectionPtr const&);
    void onDCConnection(muduo::net::TcpConnectionPtr const&);
    void onCSConnection(muduo::net::TcpConnectionPtr const&);
    void onDSConnection(muduo::net::TcpConnectionPtr const&);

private:

    HeartBeatManager _dcManager;
    ProtobufDispatcher _dispatcher;
    ProtobufCodec _codec;
    ProtobufLabCodec _dscodec;
    boost::unordered_map<DB_ID_TYPE , TableManagerPtr> _dbID2TManager;
    boost::unordered_map<std::string , DRowTablePtr> _dbID2RTable;

private:

    muduo::net::TcpServer _server4Client;
    muduo::net::TcpServer _server4CS;
    muduo::net::TcpServer _server4DS;
    TcpClientPtr _csClient;
    TcpClientPtr _dcClient;

public://TODO

    void onHeartBeat(muduo::net::TcpConnectionPtr const&,
                     MessagePtr const&,
                     muduo::Timestamp);

    void onTimeout(muduo::net::TcpConnectionPtr const&);
    void onCreateGroupKeyData(muduo::net::TcpConnectionPtr const& conn,
                              MessagePtr const& msg,
                              muduo::Timestamp receiveTime);

    void onUpdateGroupKeyData(muduo::net::TcpConnectionPtr const& conn,
                              MessagePtr const& msg,
                              muduo::Timestamp receiveTime);

    void onSysStatQuery(muduo::net::TcpConnectionPtr const& conn,
                        MessagePtr const& msg,
                        muduo::Timestamp receiveTime);

    void onRTableCreate(muduo::net::TcpConnectionPtr const& conn,
                        MessagePtr const& msg,
                        muduo::Timestamp receiveTime);

    void onRTableUpdate(muduo::net::TcpConnectionPtr const& conn,
                        MessagePtr const& msg,
                        muduo::Timestamp receiveTime);

    void onUnknownMessage(muduo::net::TcpConnectionPtr const& conn,
                          MessagePtr const& msg,
                          muduo::Timestamp receiveTime);

    void onIndexSendAck(muduo::net::TcpConnectionPtr const& conn,
                        MessagePtr const& msg,
                        muduo::Timestamp receiveTime);

private:

    void doCreateGroupKeyData(muduo::net::TcpConnectionPtr const& conn,
                              MessagePtr const& msg,
                              muduo::Timestamp receiveTime);

    void doUpdateGroupKeyData(muduo::net::TcpConnectionPtr const& conn,
                              MessagePtr const& msg,
                              muduo::Timestamp receiveTime);

    void doSysStatQuery(muduo::net::TcpConnectionPtr const& conn,
                        MessagePtr const& msg,
                        muduo::Timestamp receiveTime);

    void doRTableCreate(muduo::net::TcpConnectionPtr const& conn,
                        MessagePtr const& msg,
                        muduo::Timestamp receiveTime);

    void doRTableUpdate(muduo::net::TcpConnectionPtr const& conn,
                        MessagePtr const& msg,
                        muduo::Timestamp receiveTime);
};

#endif
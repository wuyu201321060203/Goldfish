#ifndef INITIALIZER_H
#define INITIALIZER_H

#include <string>

#include <muduo/net/EventLoop.h>
#include <muduo/net/TcpConnection.h>
#include <muduo/base/ThreadPool.h>
#include <muduo/base/Timestamp.h>
#include <muduo/base/ThreadPool.h>

class HeartBeatManager;

class Initializer
{
public:

    static int init(int , char**);
    static muduo::net::EventLoop& getEventLoop();
    static muduo::ThreadPool& getThreadPool();
    static uint32_t getSelfModuleID();
    static uint16_t getCliPort();
    static uint16_t getCSPort();
    static uint16_t getDSPort();
    static std::string getDCIP();
    static uint16_t getDCPort();
    static std::string getSelfIP();

private:

    static muduo::net::EventLoop _loop;
    static uint32_t _selfModuleID;
    static muduo::ThreadPool _threadPool;
    static uint16_t _cliPort;
    static uint16_t _csPort;
    static uint16_t _dsPort;
    static std::string _dcIP;
    static uint16_t _dcPort;
    static std::string _selfIP;

private:

    static bool parseCommandLineDull(int  , char**);
};

#endif
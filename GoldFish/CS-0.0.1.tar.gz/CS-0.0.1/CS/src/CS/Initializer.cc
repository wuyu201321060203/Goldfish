#include <iostream>

#include <boost/bind.hpp>
//#include <boost/program_options.hpp>
#include <boost/lexical_cast.hpp>

#include <muduo/base/Logging.h>

#include <CS/Config.h>
#include <CS/Initializer.h>
#include <CS/HeartBeatManager.h>

//namespace po = boost::program_options;

using namespace muduo;
using namespace muduo::net;

muduo::net::EventLoop Initializer::_loop;
muduo::ThreadPool Initializer::_threadPool;
uint32_t Initializer::_selfModuleID = 0;
uint16_t Initializer::_cliPort = 0;
uint16_t Initializer::_csPort = 0;
uint16_t Initializer::_dsPort = 0;
std::string Initializer::_dcIP;
uint16_t Initializer::_dcPort = 0;
std::string Initializer::_selfIP;

int Initializer::init(int argc , char** argv)
{
    if(!parseCommandLineDull(argc , argv))
    {
#ifdef CSDEBUG
        LOG_INFO << "fail to parse command line";
#endif
        return RET_FAIL;
    }
    _threadPool.start(DEFAULT_THREADS);
    return RET_SUCCESS;
}

EventLoop& Initializer::getEventLoop()
{
    return _loop;
}

ThreadPool& Initializer::getThreadPool()
{
    return _threadPool;
}

uint32_t Initializer::getSelfModuleID()
{
    return _selfModuleID;
}

uint16_t Initializer::getCliPort()
{
    return _cliPort;
}

uint16_t Initializer::getCSPort()
{
    return _csPort;
}

uint16_t Initializer::getDSPort()
{
    return _dsPort;
}

std::string Initializer::getDCIP()
{
    return _dcIP;
}

uint16_t Initializer::getDCPort()
{
    return _dcPort;
}

std::string Initializer::getSelfIP()
{
    return _selfIP;
}

bool Initializer::parseCommandLineDull(int argc , char* argv[])
{
    STDSTR selfModuleID(argv[1]);
    STDSTR cliPort(argv[2]);
    STDSTR csPort(argv[3]);
    STDSTR dsPort(argv[4]);
    STDSTR dcIP(argv[5]);
    STDSTR dcPort(argv[6]);
    STDSTR selfIP(argv[7]);
    _selfModuleID = boost::lexical_cast<uint32_t>(selfModuleID);
    _cliPort = boost::lexical_cast<uint16_t>(cliPort);
    _csPort = boost::lexical_cast<uint16_t>(csPort);
    _dsPort = boost::lexical_cast<uint16_t>(dsPort);
    _dcIP = dcIP;
    _dcPort = boost::lexical_cast<uint16_t>(dcPort);
    _selfIP = selfIP;
    return true;
}